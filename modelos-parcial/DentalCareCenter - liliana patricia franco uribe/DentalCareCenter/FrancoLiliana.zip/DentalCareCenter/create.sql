CREATE TABLE if NOT EXISTS dentists (id INT, dentalLicense INT, lastname VARCHAR(100), name VARCHAR(100));
CREATE TABLE if NOT EXISTS patients (id INT, idCard INT, lastname VARCHAR(100), name VARCHAR(100), address VARCHAR(100), registrationDate DATE);
